package question_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Defects {
 
  public static void insertDefects(String name, String desc) throws Exception {
	  try {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		  Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/petlifecycle_info?useSSL=false", "root", "JaiMataDi@91");
		 
		  Statement stmt = conn.createStatement();
		
		  String insert = "INSERT INTO defects (Defects_Name, Defects_Description) VALUES ( '"+name+"', '"+desc+"');";
		  stmt.executeUpdate(insert);
		  
		  }
		  catch(Exception e) {
		  e.printStackTrace();
		  } 
  }
}