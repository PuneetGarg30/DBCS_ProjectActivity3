package question_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Task {
 
  public static void insertTask(String name, String desc, String c, String d, String e) throws Exception {
	  try {
		  Class.forName("com.mysql.cj.jdbc.Driver");
		  Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/petlifecycle_info?useSSL=false", "root", "JaiMataDi@91");
		  Statement stmt = conn.createStatement();
		
		  String insert = "INSERT INTO task (task_Name, task_Description, role, used_artifacts, produced_artifacts) VALUES ( '"+name+"', '"+desc+"', '"+e+"', '"+d+"', '"+c+"');";
		  stmt.executeUpdate(insert);
		  }
	  
		  catch(Exception e1) {
		  e1.printStackTrace();
		  } 
  }
}