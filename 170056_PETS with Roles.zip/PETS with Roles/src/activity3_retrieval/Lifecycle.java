package activity3_retrieval;

public class Lifecycle {

	public static void retLC(String name, String desc) throws Exception {
		
	}
}
